# FlockingChase (Variant, Godot 4 + C#)

Simple top-down demo with **Boids** flocking.
- Player: orange **circle**
- Enemies: teal **triangles**
- Door: pink/purple, spawns a chasing wave

## Controls
- WASD / Arrows: move
- Shift: sprint

## Credits / Citations
- Boids algorithm concept: Craig Reynolds, via Wikipedia (https://en.wikipedia.org/wiki/Boids)
- Code structure assistance: ChatGPT (OpenAI). Nodes, setup, and gameplay integration done by me.
